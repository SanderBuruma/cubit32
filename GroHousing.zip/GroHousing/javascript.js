let lijstInformatie, lijstLengte;

window.setTimeout(haalKamerInformatie,0);

function haalKamerInformatie(a){//trigger when >practice< is clicked
    console.log('trigger')
    xmlhttp.open("GET","callroomlistinfo.php");
    xmlhttp.send();
}

if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp = new XMLHttpRequest();
    console.log('not IE 5 or 6')
} else {
    // code for IE6, IE5
    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    console.log('IE 5 or 6')
}


let showAllInfo = function(click) {
    console.log(click)
}
document.getElementById('maindiv').addEventListener("click",showAllInfo)

console.log(xmlhttp)
xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {//kamer informatie laden
        lijstInformatie = this.responseText.split("%SPLIT%")
        // lijstInformatie.pop().unshift();
        lijstInformatie.pop(); lijstInformatie.shift();
        lijstLengte = Math.floor(lijstInformatie.length/7+1)
        console.log(lijstInformatie)
        console.log(lijstLengte)
        for (let i = 0; i < lijstLengte; i++){
            console.log(lijstInformatie[0+i*7])
            let kamerdiv = document.createElement('div');
            kamerdiv.id = 'kamer'+lijstInformatie[0+i*7];
            kamerdiv.classList.add('kamerdiv');
            document.getElementById('maindiv').appendChild(kamerdiv)
            let thumbnail = document.createElement('img');
            thumbnail.src='thumbnails/'+lijstInformatie[1+i*7];
            thumbnail.height="128";
            thumbnail.width="128";
            thumbnail.classList.add('thumbnail');
            kamerdiv.appendChild(thumbnail);
            let informatie = document.createElement('div');
            informatie.innerHTML = 'Address: '+lijstInformatie[2+i*7]+'<br> Monthly Rent: € '+lijstInformatie[3+i*7]+'<br> Surface: '+lijstInformatie[4+i*7]+' m2'+'<br>Plaats: '+lijstInformatie[5+i*7];
            informatie.classList.add('kamerlijstinfotekst')
            kamerdiv.appendChild(informatie)
        }
    }
}