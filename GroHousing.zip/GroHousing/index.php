<!DOCTYPE html
PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!--
Author: Sander "Cubit32" Buruma
loosely based on typeracer.com
-->
<html>
<head>
    <title>GroHousing!</title>
    <link rel="stylesheet" href="./main.css">
</head>
<body>
    <div id="maindiv"></div>
    <div id="infodiv" hidden="true"></div>
    <script src="./javascript.js"></script>
</body>
</html>