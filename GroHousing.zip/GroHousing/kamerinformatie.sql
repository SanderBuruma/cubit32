-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 27, 2018 at 09:49 PM
-- Server version: 5.7.23-0ubuntu0.18.04.1
-- PHP Version: 7.2.10-0ubuntu0.18.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `GroHousing`
--

-- --------------------------------------------------------

--
-- Table structure for table `kamerinformatie`
--

CREATE TABLE `kamerinformatie` (
  `id` int(11) NOT NULL,
  `adres` char(32) NOT NULL,
  `telefoonnummer` varchar(12) NOT NULL,
  `email` char(32) NOT NULL,
  `maandhuur` int(5) NOT NULL,
  `thumbnail` char(128) NOT NULL,
  `vierkantemeter` int(11) NOT NULL,
  `type` varchar(32) NOT NULL,
  `availablefrom` varchar(32) NOT NULL,
  `kitchen` varchar(32) NOT NULL,
  `bathroom` varchar(32) NOT NULL,
  `nrhousemates` int(11) NOT NULL,
  `distancecitycentre` int(11) NOT NULL,
  `distancezernike` int(11) NOT NULL,
  `distancetrainstation` int(11) NOT NULL,
  `plaats` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kamerinformatie`
--

INSERT INTO `kamerinformatie` (`id`, `adres`, `telefoonnummer`, `email`, `maandhuur`, `thumbnail`, `vierkantemeter`, `type`, `availablefrom`, `kitchen`, `bathroom`, `nrhousemates`, `distancecitycentre`, `distancezernike`, `distancetrainstation`, `plaats`) VALUES
(1, 'Boterstraat 5', '06-31415927', 'jantje@grietje.nl', 320, 'kamertje1.png', 15, 'Independent Room', '2018-11-01', 'Shared', 'Shared', 0, 1500, 250, 1000, 'Groningen'),
(3, 'Kaasweg 91', '06-41421356', 'glenda@goudenweg.nl', 240, 'kamer2.png', 20, 'Room / Shared Facilities', '2019-01-01', 'None', 'Shared', 2, 25, 1000, 100, 'Tolhek'),
(4, 'Wolkenweg 288', '06-73205080', 'maria@hulpvangroningers.nl', 144, 'kamer3.png', 18, 'Independent Studio', '2019-06-01', 'Shared', 'Shared', 3, 4000, 3000, 3500, 'Dorkwerd'),
(5, 'Evangelieweg 13', '06-54983445', 'simon@eindstation.nl', 25, 'tent.png', 1, 'Independent Room', '2019-07-01', 'None', 'Included', 5, 1000, 500, 250, 'Groningen'),
(6, 'Informatieweg 271', '06-27172717', 'natural@log.nl', 270, 'huisje1.png', 27, 'Room / Shared Facilities', '2020-01-01', 'None', 'Shared', 2, 0, 1500, 100, 'Midwolden'),
(7, 'Royaalstraat 34', '06-14486499', 'koning@huis.nl', 860, 'kamer4.png', 40, 'Independent Studio', '2018-10-01', 'Included', 'Included', 0, 750, 750, 100, 'Groningen'),
(8, 'Royaalstraat 33', '06-14486499', 'koningin@tenten.nl', 620, 'kamer5.png', 35, 'Independent Studio', '2018-10-01', 'Included', 'Included', 0, 750, 750, 100, 'Groningen');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kamerinformatie`
--
ALTER TABLE `kamerinformatie`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kamerinformatie`
--
ALTER TABLE `kamerinformatie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
